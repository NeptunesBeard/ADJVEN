package pojos;

import javax.persistence.*;

@Entity
@Table(name="VendorTable")
public class Vendor 
{
	
	private Integer id;
	private String name;
	private String email;
	private String city;
	private long mobilenumber;
	
	public Vendor()
	{
		System.out.println("In Vendor Constructor");
	}
	
	public Vendor(String name, String email, String city, long mobilenumber) {
		super();
		this.name = name;
		this.email = email;
		this.city = city;
		this.mobilenumber = mobilenumber;
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="vendorId")
	public Integer getId() {
		return id;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	@Column(length = 30,unique=true)
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	@Column(length = 10,unique=true)
	public long getMobilenumber() {
		return mobilenumber;
	}
	public void setMobilenumber(long mobilenumber) {
		this.mobilenumber = mobilenumber;
	}
	
	
	@Override
	public String toString() {
		return "Vendor [id=" + id + ", name=" + name + ", email=" + email + ", city=" + city + ", mobilenumber="
				+ mobilenumber + "]";
	}
	
	
	
}
