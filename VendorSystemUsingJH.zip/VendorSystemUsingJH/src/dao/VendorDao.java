package dao;

import java.util.List;

import org.hibernate.*;

import pojos.Vendor;
import static utils.HibernateUtils.*;
public class VendorDao implements VendorInterface{

	
	@Override
	public List<Vendor> getAllVendors(){
		
		List<Vendor> vendorList = null;	
		
		String Jpql = "Select v from Vendor v";
		Session sh = getSf().getCurrentSession();
		Transaction ts = sh.beginTransaction();
		
		try
		{
			vendorList = sh.createQuery(Jpql,Vendor.class).getResultList();
			ts.commit();
		}
		catch (RuntimeException e) 
		{
				if(ts != null) {
					ts.rollback();
				}
				throw e;
		}
		return vendorList;
	}

	
	@Override
	public void updateVendor(int id,String city, long mobno)
	{
		//System.out.println("DataUpdated successfully : ");
			
		Vendor v = null;
		Session sh = getSf().getCurrentSession();
		Transaction ts = sh.beginTransaction();
		
		try
		{
			v = sh.get(Vendor.class,id);
			v.setCity(city);
			v.setMobilenumber(mobno);
			ts.commit();
		}
		catch (RuntimeException e) 
		{
				if(ts != null) {
					ts.rollback();
				}
				throw e;
		}
		System.out.println("DataUpdated successfully : ");
	}

	@Override
	public void deleteVendor(int id)
	{
		
		Vendor v = null;
		Session sh = getSf().getCurrentSession();
		Transaction ts = sh.beginTransaction();
		
		try
		{
			v = sh.get(Vendor.class,id);
			sh.delete(v);
			ts.commit();
		}
		catch (RuntimeException e) 
		{
				if(ts != null) {
					ts.rollback();
				}
				throw e;
		}
	
		System.out.println("Data deleted successfully : ");
	}

	@Override
	public void insertVendorDetails(Vendor v)
	{
		
		Session sh = getSf().getCurrentSession();
		Transaction ts = sh.beginTransaction();
		
		try
		{
			sh.save(v);
			ts.commit();
		}
		catch (RuntimeException e) 
		{
				if(ts != null) {
					ts.rollback();
				}
				throw e;
		}
		System.out.println("Data inserted successfully : ");
	}
}
