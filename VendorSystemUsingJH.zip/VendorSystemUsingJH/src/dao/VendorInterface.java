package dao;

import java.util.List;

import pojos.Vendor;

public interface VendorInterface {

	List<Vendor> getAllVendors();
	public void updateVendor(int id ,String city,long mobno);
	public void deleteVendor(int id);
	public void insertVendorDetails(Vendor v);
}
