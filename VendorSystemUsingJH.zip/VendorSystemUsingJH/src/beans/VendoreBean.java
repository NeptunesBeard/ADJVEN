package beans;

import java.util.List;

import dao.VendorDao;
import pojos.Vendor;

public class VendoreBean {

	private VendorDao vederObj = null;
	private List<Vendor> vendorList;
	private int id;
	
	private String username, email, city;
	private long mobNo;
	private Vendor vendorObj = null;
	
	
	public void setUsername(String username) {
		this.username = username;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setMobNo(long mobNo) {
		this.mobNo = mobNo;
	}

	public void setId(int id) {
		this.id = id;
		System.out.println("In set method");
	}

	public VendoreBean()throws Exception
	{
		vederObj = new VendorDao();
	}
	
	public List<Vendor> getAllVendor()throws Exception
	{
		vendorList = vederObj.getAllVendors();
		System.out.println("In bean method");
		return vendorList;
	}
	
	public void deleteSpecificVendor()throws Exception
	{
		vederObj.deleteVendor(id);
		System.out.println("In delete method");
	}
	
	public void insertVendorData()throws Exception
	{
		vendorObj = new Vendor(username, email, city, mobNo);
		vederObj.insertVendorDetails(vendorObj);
		System.out.println("In inserted method");
	}
	
	public void updateSpecificVendor()throws Exception
	{
		vederObj.updateVendor(id, city, mobNo);
		System.out.println("In Update method "+id+ " "+city+" "+ mobNo);
	}
}
